import nltk
from nltk.corpus import wordnet
from nltk.tokenize import word_tokenize, sent_tokenize
import random

nltk.download('punkt')
nltk.download('wordnet')

# Function to find synonyms for a word
def get_synonyms(word):
    synonyms = []
    for syn in wordnet.synsets(word):
        for lemma in syn.lemmas():
            synonyms.append(lemma.name())
    return list(set(synonyms))

# Function to paraphrase a sentence
def paraphrase_sentence(sentence):
    words = word_tokenize(sentence)
    paraphrased_words = []

    for word in words:
        synonyms = get_synonyms(word)
        if synonyms:
            paraphrased_word = random.choice(synonyms)
            paraphrased_words.append(paraphrased_word)
        else:
            paraphrased_words.append(word)

    paraphrased_sentence = ' '.join(paraphrased_words)
    return paraphrased_sentence

# Function to paraphrase a paragraph
def paraphrase_paragraph(paragraph):
    sentences = sent_tokenize(paragraph)
    paraphrased_sentences = []

    for sentence in sentences:
        paraphrased_sentence = paraphrase_sentence(sentence)
        paraphrased_sentences.append(paraphrased_sentence)

    paraphrased_paragraph = ' '.join(paraphrased_sentences)
    return paraphrased_paragraph

# Input paragraph to be paraphrased
input_paragraph = "This is a sample paragraph that we want to paraphrase. It contains various words and phrases."

paraphrased_paragraph = paraphrase_paragraph(input_paragraph)
print(paraphrased_paragraph)
