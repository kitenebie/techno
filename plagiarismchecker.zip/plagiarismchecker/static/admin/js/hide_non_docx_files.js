(function($){
    $(document).ready(function(){
        // Hides non-docx files when selecting a file in the Django admin panel
        $('input[name="file"]').attr('accept', '.docx');
    });
})(django.jQuery);
