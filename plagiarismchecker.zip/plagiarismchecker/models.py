# models.py
from django.db import models
from django.core.validators import FileExtensionValidator
from django.core.exceptions import ValidationError
from django.utils import timezone

class UploadedFile(models.Model):
    CATEGORY_CHOICES = [
        ('Technology and Software Development', 'Technology and Software Development'),
        ('Engineering and Electronics', 'Engineering and Electronics'),
        ('Health and Medicine', 'Health and Medicine'),
        ('Environmental Science', 'Environmental Science'),
        ('Education', 'Education'),
        ('Social Sciences', 'Social Sciences'),
        ('Data Science and Analytics', 'Data Science and Analytics'),
        ('Creative Arts and Media', 'Creative Arts and Media'),
        ('Urban Planning and Architecture', 'Urban Planning and Architecture'),
        ('Communication and Networking', 'Communication and Networking'),
    ]

    title = models.CharField(max_length=255, primary_key=True, help_text="Enter a unique title for your file. This will serve as the primary identifier.")
    authors = models.CharField(max_length=200, default="", help_text="Provide the names of the authors involved in creating the file.")
    file = models.FileField(
        upload_to='',
        validators=[FileExtensionValidator(allowed_extensions=['docx'])],
        help_text="Upload a document file with a '.docx' extension only."
    )
    category = models.CharField(max_length=255, choices=CATEGORY_CHOICES, default='Technology and Software Development', help_text="Choose the relevant category from the provided options.")
    uploaded_at = models.DateTimeField(default=timezone.now, help_text="This field is automatically generated with the current date and time of upload.")

    def __str__(self):
        return self.title
