from django.shortcuts import render, redirect,get_object_or_404
from django.http import HttpResponse
from plagiarismchecker.algorithm import main
from docx import *
from plagiarismchecker.algorithm import fileSimilarity
import PyPDF2 
import datetime


from .models import UploadedFile
from .forms import UploadedFileForm
import os
from django.conf import settings
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import logout, authenticate
from django.contrib.auth.models import Group  # Import the Group model

import difflib
import nltk
from nltk.tokenize import word_tokenize

nltk.download('punkt')  # Download NLTK data
nltk.download('stopwords')

from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_protect
from .forms import RegistrationForm
from django.contrib.auth import authenticate, login as auth_login
from .models import UploadedFile
from docx import Document
import speech_recognition as sr

getUser = None
def landing(request):
    return render(request, 'reg/home.html')

def login(request):
    if request.method == 'POST':
        user = authenticate(request, username=request.POST.get('username'), password=request.POST.get('password1'))
        if user is not None:
            if user.is_active:
                auth_login(request, user)  # Log in the user
                return articles(request)
        # Handle authentication failure, redirect to login page or show an error message
        return render(request, 'reg/login.html', {"message": "Invalid login credentials."})
    else:
        form = UserCreationForm()
        context = {"form": form}
        return render(request, 'reg/login.html', context)



def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            group, created = Group.objects.get_or_create(name='Users-only')
            user.groups.add(group)
            return render(request, 'reg/login.html', {"created": "Account Successfully Created!"})  # Redirect to a success page
        else:
            message = "Please enter valid details."
            context = {"form": form, "message": message}
            return render(request, 'reg/register.html', context)
    else:
        form = UserCreationForm()
        context = {"form": form}
        return render(request, 'reg/register.html', context)


def local(request):
    if not request.user.is_anonymous:
        all_titles = UploadedFile.objects.values_list('title', flat=True)
        title_list = list(all_titles)
        return render(request, 'dashboard/content-checker.html', {'current_option': 'context', 'result': title_list, 'percentage': 0.00 })
    else:
        return redirect("/")

@csrf_protect
def localFile(request):
    if not request.user.is_anonymous:
        all_titles = UploadedFile.objects.values_list('title', flat=True)
        title_list = list(all_titles)
        doc_file = ""
        value1 = ""
        value2 = ""
        error = ""
        print(request.POST.get('option'))
        if request.method == 'POST':
            if request.POST.get('option') == "upload" and request.FILES['docfile1'].size > 0:
                selected_title = request.POST.get('selecteFile')
                matching_files = UploadedFile.objects.filter(title=selected_title)
                
                # Read the uploaded file content correctly
                for file in matching_files:
                    # Get file content from the database field
                    doc_file = file.file.name
                    file_path = os.path.join(settings.MEDIA_ROOT, doc_file)
                    if os.path.exists(file_path):
                        if (str(request.FILES['docfile1'])).endswith(".docx"):
                            document = Document(request.FILES['docfile1'])
                            for para in document.paragraphs:
                                value1 += para.text
                            document = Document(file_path)
                            for para in document.paragraphs:
                                value2 += para.text

                            result = fileSimilarity.findFileSimilarity(value1,value2)
                            print("Output..................!!!!!!!!",result)
                        
                            context = {'result': title_list, 'matching_files': matching_files, 'percentage': result,
                                    'current_option': 'upload', 'searchValue': selected_title}
                            return render(request, 'dashboard/content-checker.html', context)  
                    
        
            if request.POST.get('option') == "context":
                selected_title = request.POST.get('selecteFile')
                matching_files = UploadedFile.objects.filter(title=selected_title)
                
                # Read the uploaded file content correctly
                for file in matching_files:
                    # Get file content from the database field
                    doc_file = file.file.name
                    file_path = os.path.join(settings.MEDIA_ROOT, doc_file)
                    if os.path.exists(file_path)  and request.POST['text_input'] is not None and request.POST['text_input'] != '':
                        document = Document(file_path)
                        for para in document.paragraphs:
                            value1 += para.text

                        result = fileSimilarity.findFileSimilarity(value1, request.POST['text_input'])
                        print("Output..................!!!!!!!!",result)
                        
                        context = {'result': title_list, 'matching_files': matching_files, 'percentage': result, 'current_option': 'context',
                                'text_area': request.POST['text_input'], 'searchValue': selected_title
                                }
                        return render(request, 'dashboard/content-checker.html', context) 
                
        return render(request, 'dashboard/content-checker.html', {'result': title_list, "fileNotExist": "Please ensure that you have entered the information correctly in the required fields. The item you have chosen does not appear to exist in the database!"})  
    else:
        return redirect("/")                   
    
    
def upload_file(request):
    if not request.user.is_anonymous:
        if request.method == 'POST':
            form = UploadedFileForm(request.POST, request.FILES)
            if form.is_valid():
                form.save()
                return HttpResponse('File uploaded successfully.')
        else:
            form = UploadedFileForm()
        return render(request, 'upload_file.html', {'form': form})
    else:
        return redirect("/")

def modify_file(request, file_id):
    request.FILES['docfile1'] = get_object_or_404(UploadedFile, pk=file_id)
    return HttpResponse('File modified successfully.')

# speech_to_text
def voice_to_text(request):
    if not request.user.is_anonymous:
        # Initialize the recognizer
        recognizer = sr.Recognizer()
        text_input = ''
        try:
            with sr.Microphone() as source:
                recognizer.adjust_for_ambient_noise(source, duration=1)  # Adjust for ambient noise
                print("Speak something...")
                audio = recognizer.listen(source, timeout=2)  # Set a timeout (2 seconds in this example)
                voice_text = recognizer.recognize_google(audio)
        except sr.UnknownValueError:
            voice_text = "Could not understand the audio"
        except sr.RequestError as e:
            voice_text = "Error with the service; {0}".format(e)
        except sr.WaitTimeoutError:
            voice_text = "No voice detected within the timeout."
        
        text_input += "\n" + voice_text
                    
        text_area = text_input

        all_titles = UploadedFile.objects.values_list('title', flat=True)
        title_list = list(all_titles)
        
        context = {'result': title_list, 'text_area': text_area, 'current_option': 'context'}
        return render(request, 'dashboard/content-checker.html', context)
    else:
        return redirect("/")


def split_docx_into_pages(doc):
    pages = []
    current_page = []
    for paragraph in doc.paragraphs:
        if paragraph.style and "PageBreakStyle" in paragraph.style.name:
            if current_page:
                pages.append(current_page)
            current_page = []
        else:
            current_page.append(paragraph)

    if current_page:
        pages.append(current_page)

    return pages

def view_docx(request, value, status, ArticleTitle):
    if not request.user.is_anonymous:
        # Load the DOCX file (replace 'sample.docx' with the path to your DOCX file)
        files = UploadedFile.objects.filter(title=ArticleTitle)
        file_path = os.path.join(settings.MEDIA_ROOT, value)
        doc = Document(file_path)
        
        # Split the DOCX into pages
        pages = split_docx_into_pages(doc)

        # Extract the text and formatting from each page
        page_data = []
        for page in pages:
            page_text = []
            for paragraph in page:
                para = {
                    'text': paragraph.text,
                    'alignment': paragraph.alignment,
                    'bold': any(run.bold for run in paragraph.runs),
                    # Add more formatting attributes as needed
                }
                page_text.append(para)
            page_data.append(page_text)
        visible = ""
        if status == "isAvailable":
            visible = "100%"
        else:
            visible = "40%"

        return render(request, 'dashboard/preview-article.html', {'page_data': page_data, 'file_path': "/media/" + value, "visible": visible,
                                                                  'files':files})
    else:
        return redirect("/")


def articles(request):
    if not request.user.is_anonymous:
        current_year = datetime.datetime.now().year
        files = UploadedFile.objects.all()
        for file in files:
            uploaded_year = file.uploaded_at.year
            difference = current_year - uploaded_year
            file.is_available = difference >= 3
                
        context = {"files": files, "current_year": current_year}
        return render(request, 'dashboard/articles.html', context)
    else:
        return redirect("/")

def searchEngine(request):
    if not request.user.is_anonymous:
        if request.method == 'POST':
            filesCate = UploadedFile.objects.all()
            print(filesCate)
            SelectedOption = request.POST.get('filteredSearch') 
            if SelectedOption != ' All ':
                print("NOT ALL: ")
                print(SelectedOption)
                search_Category = request.POST.get('filteredSearch').strip()
                search_title = request.POST.get('search', '').strip()  # Ensure the title is not empty
                if search_title:
                    current_year = datetime.datetime.now().year
                    files = UploadedFile.objects.filter(title__icontains=search_title, category=search_Category)
                    for file in files:
                        uploaded_year = file.uploaded_at.year
                        difference = current_year - uploaded_year
                        file.is_available = difference >= 3

                    context = {"files": files, 'filesCate': filesCate, "current_year": current_year, "searched": search_title, 'searchedFiltered': search_Category}
                    return render(request, 'dashboard/articles.html', context)
            if SelectedOption == ' All ':
                print("ALL: ")
                print(SelectedOption)
                filesCate = UploadedFile.objects.all()
                search_title = request.POST.get('search', '').strip()  # Ensure the title is not empty
                if search_title:
                    current_year = datetime.datetime.now().year
                    files = UploadedFile.objects.filter(title__icontains=search_title)
                    for file in files:
                        uploaded_year = file.uploaded_at.year
                        difference = current_year - uploaded_year
                        file.is_available = difference >= 3

                    context = {"files": files, 'filesCate': filesCate, "current_year": current_year, "searched": search_title}
                    return render(request, 'dashboard/articles.html', context)
                        

        # Handle the case when the form is not submitted or the title is empty
        return render(request, 'dashboard/articles.html')
    else:
        return redirect("/")
    
def filterByCategory(request, value):
    if not request.user.is_anonymous:
        search_Category = value.strip()  # Ensure the title is not empty
        if search_Category:
            current_year = datetime.datetime.now().year
            files = UploadedFile.objects.filter(category__icontains=search_Category)
            for file in files:
                uploaded_year = file.uploaded_at.year
                difference = current_year - uploaded_year
                file.is_available = difference >= 3
            filesCate = UploadedFile.objects.all()
            print("filesCate: ")
            print(filesCate)

            context = {"files": files, 'filesCate': filesCate, "current_year": current_year, "filter": "active", "searchedFiltered": search_Category}
            return render(request, 'dashboard/articles.html', context)
    else:
        return redirect("/")
