from django.urls import path, include
from . import views
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.landing, name="landing"),
    path('plagiarizer/', views.local, name='local'),
    path('localFile/', views.localFile, name='localFile'),
    
    
    path('login/', views.login, name='login'),
    
    path('register/', views.register, name='register'),
    
    
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    
    path('social-auth/', include('social_django.urls', namespace='social')),
    
    path('voice_to_text/', views.voice_to_text, name='voice_to_text'),
    
    path('view/<str:value>/<str:status>/<str:ArticleTitle>', views.view_docx, name='view_docx'),
    path('articles/', views.articles, name='articles'),
    path('searchEngine/', views.searchEngine, name='searchEngine'),
    path('article/filter/<str:value>/', views.filterByCategory, name='filterCategory'),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)