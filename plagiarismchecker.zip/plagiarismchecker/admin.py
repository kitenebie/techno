from django.contrib import admin
from .models import UploadedFile

class UploadedFileAdmin(admin.ModelAdmin):
    list_display = ['title', 'authors', 'file', 'category', 'uploaded_at']
    search_fields = ['title', 'authors', 'category']

    class Media:
        js = ('admin/js/hide_non_docx_files.js',)
        
admin.site.register(UploadedFile,UploadedFileAdmin)
