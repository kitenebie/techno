from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import UploadedFile

class UploadedFileForm(forms.ModelForm):
    search = forms.CharField(
        required=False,
        label='Search',
        widget=forms.TextInput(attrs={'placeholder': 'Search...'})
    )
    class Meta:
        model = UploadedFile
        fields = ('title', 'authors', 'file')
        exclude = ('uploaded_at',)

class RegistrationForm(UserCreationForm):
    # Add any additional fields here
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

from django import forms

class VoiceToTextInputForm(forms.Form):
    text_input = forms.CharField(widget=forms.Textarea(attrs={'rows': 5}))